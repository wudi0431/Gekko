﻿window.PATH = {
    DEFAULTINDEX: 'sdp/index',
    VIEWS_PATH: 'diyfhx/dest/views/',
    TEMPLATES_PATH: 'diyfhx/dest/templates/',
    BASEURL: '/webapp/'
};

function getViewsPath() {
    return window.PATH.VIEWS_PATH;
}
function getTemplatesPath() {
    return window.PATH.TEMPLATES_PATH;
}

function buildViewPath(htmlpath) {
    return getViewsPath() + htmlpath;
}

function buildViewTemplatesPath(htmlpath) {
    return 'text!' + getTemplatesPath() + htmlpath;
}

require.config({
    baseUrl: window.PATH.BASEURL,
    shim: {
        _: { exports: '_' },
        B: { deps: ['_', '$'], exports: 'Backbone' },
        App: { deps: ['B'] }
    },
    paths: {
        'diyfhxModel': 'diyfhx/dest/models/diyfhx.model',
        'diyfhxStore': 'diyfhx/dest/models/diyfhx.store',
        'diyfhxCommon': 'diyfhx/dest/common/diyfhx.common'
    }
});

require(['libs', 'App'], function (libs, App) {
    var app = new App({
        'defaultView': window.PATH.DEFAULTINDEX,
        'viewRootPath': window.PATH.VIEWS_PATH
    });
});

