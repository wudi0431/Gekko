﻿
window.LIBS_URL = 'res/libs';
window.APP_PATH = 'diyfhx/';
window.COMMON_PATH = 'app/common/';
window.MODELS_PATH = APP_PATH + 'models/';
//var link
window.sdplinks = [];

window.PATH = {
  DEFAULTINDEX: 'sdp/index',
  VIEWS_PATH: APP_PATH + 'views/',
  BASEURL: '/webapp/'
};

function getViewsPath() {
  return APP_PATH + 'templates/';
}

function buildViewPath(htmlpath) {
  return getViewsPath() + htmlpath;
}

function buildViewTemplatesPath(htmlpath) {
  
  return 'text!' + getViewsPath() + htmlpath;
}

require.config({
  baseUrl: window.PATH.BASEURL,
  shim: {
    _: { exports: '_' },
    B: { deps: ['_', '$'], exports: 'Backbone' },
    App: { deps: ['B'] }
  },
  paths: {
    'Config': APP_PATH + 'common/config',
    'DiyCommon': APP_PATH + 'common/diy.common',
    "InternationalAirportCities": APP_PATH + "common/internationalairportcities",
    "InLandAirportCities": APP_PATH + "common/inlandairportcities",
    "AirLineCompany": APP_PATH + "common/airlinecompany",
    "HotelCities": APP_PATH + "common/hotelcities",
    'Cities': APP_PATH + 'common/cities',
    'Countries': APP_PATH + 'common/countries',
    "StartCities": APP_PATH + "common/startcities",
    "Destinations": APP_PATH + "common/destinations",
    'StoreOperation': APP_PATH + 'common/storeoperation',

    'CommonModel': APP_PATH + 'models/common.model',
    'DiyStore': APP_PATH + 'models/diy.store',
    'DPModel': APP_PATH + 'models/dp.model',
    'DPStore': APP_PATH + 'models/dp.store',
    'SDPModel': APP_PATH + 'models/sdp.model',
    'SDPStore': APP_PATH + 'models/sdp.store',
    'DPModel': APP_PATH + 'models/dp.model',
    'COMModel': APP_PATH + 'models/commonservice.model',
    'SHXModel': APP_PATH + 'models/shx.model',


    'Mask': APP_PATH + 'widget/tscrollmask',
    'ErrorPage': APP_PATH + 'widget/terrorPage',
    "Dialogs": APP_PATH + 'widget/tdialogs',
    "TGroupList": APP_PATH + 'widget/tgrouplist',
    "TRichList": APP_PATH + 'widget/trichlist',
    "Validates": APP_PATH + 'widget/validates',
    "UInum": APP_PATH + 'widget/uinum',
    "TSwitch": APP_PATH + 'widget/tswitch',
    "Vtils": APP_PATH + "widget/tvtils",
    'Slider': APP_PATH + 'widget/tslider',
    'ImageSlider': APP_PATH + 'widget/timageslider',
    'Swipe': APP_PATH + 'widget/tswipe',
    'HotelFac': APP_PATH+'widget/hotel.info',
    "Coupon": APP_PATH + 'widget/order/coupon',

    
    
    "TTD": APP_PATH + "widget/list.ttd",
    "vBase": APP_PATH + "widget/list/vBase",
    "Listism": APP_PATH + "widget/list/Listism",
    "Datatism": APP_PATH + "widget/list/Datatism",
    "Templatism": APP_PATH + "widget/list/Templatism",
    "AddressRegion": APP_PATH + 'widget/address/region',
    "AddressSelect": APP_PATH + 'widget/address/select',
    "AddressEdit": APP_PATH + 'widget/address/edit',
    'Delivery': APP_PATH + 'widget/order/delivery',
    "BookingMaker": APP_PATH + 'widget/order/bookingmaker',
    "SDPBookingMaker": APP_PATH + 'widget/order/sdpbookingmaker',
    "DPCheckAvailable": APP_PATH + 'widget/order/dpcheckavailable',
    "SDPCheckAvailable": APP_PATH + 'widget/order/dpcheckavailable',
    "OrderDetailFilght": APP_PATH + 'widget/orderdetail/flight',
    "OrderDetailHotel": APP_PATH + 'widget/orderdetail/hotel',
    "OrderDetailOther": APP_PATH + 'widget/orderdetail/other',
    "OrderDetailSummary": APP_PATH + 'widget/orderdetail/summary',
    "OrderDetailXResource": APP_PATH + 'widget/orderdetail/xresource',

    "detail.additionalinfo": APP_PATH + 'views/sdp/detail.additionalinfo',
    "detail.allInfo": APP_PATH + 'views/sdp/detail.allInfo',
    "detail.car": APP_PATH + 'views/sdp/detail.car',
    "detail.flightinfo": APP_PATH + 'views/sdp/detail.flightinfo',
    "detail.giftinfo": APP_PATH + 'views/sdp/detail.giftinfo',
    "detail.insurance": APP_PATH + 'views/sdp/detail.insurance',
    "detail.hotelinfo": APP_PATH + 'views/sdp/detail.hotelinfo',
    "detail.privilegeinfo": APP_PATH + 'views/sdp/detail.privilegeinfo',
    
    'dpxresources': APP_PATH + 'views/dp/xresources',
    'orderfill':APP_PATH + 'views/dp/order.fill',
    'detail.htl.hotelboard':APP_PATH + 'views/sdp/detail.htl.hotelboard',
    'detail.htl.specialNote':APP_PATH + 'views/sdp/detail.htl.specialNote',
    'Flight': APP_PATH + 'common/flight',
    'detail.htl.picture.browser.slider': APP_PATH + 'views/sdp/detail.htl.picture.browser.slider'
  }
});

require(['libs', 'App'], function (libs, App) {

  var app = new App({
    'defaultView': window.PATH.DEFAULTINDEX,
    'viewRootPath': (window.PATH.VIEWS_PATH)
  });

});
